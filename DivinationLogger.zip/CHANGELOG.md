# 1.1.0

Added Excel logging

# 1.0.1

Text updates

# 1.0.0

Initial Release - CSV only