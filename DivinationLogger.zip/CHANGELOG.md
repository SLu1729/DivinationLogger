# 1.2.0

Added some formatting options

# 1.1.1

Hopefully fixed divination logging in acts 2+

# 1.1.0

Added Excel logging

# 1.0.1

Text updates

# 1.0.0

Initial Release - CSV only